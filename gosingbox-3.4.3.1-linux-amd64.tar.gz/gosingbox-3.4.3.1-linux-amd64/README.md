# gosingbox (Go, sing-box data plane) — standalone package

Linux amd64 self-contained static build (no Docker, no Node.js, no glibc
dependency — runs on Alpine 3.21 / 128MB LXC).

## Run
    ./bin/run.sh
    # or set env vars first (see env.example)

## Systemd
    sudo cp gosingbox.service /etc/systemd/system/
    sudo mkdir -p /opt/gosingbox
    sudo cp -r . /opt/gosingbox/
    # edit /opt/gosingbox/env.example -> /opt/gosingbox/env with your panel SECRET_KEY
    sudo systemctl daemon-reload
    sudo systemctl enable --now gosingbox

## Binary layout
    bin/gosingbox   Go binary (static, sing-box 1.14.3 embedded)
    bin/geocheck    geo detection helper (v0.3.0-cn)
    bin/run.sh      launcher

## Memory
    gosingbox RSS ~45MB (sing-box embedded, single binary).
